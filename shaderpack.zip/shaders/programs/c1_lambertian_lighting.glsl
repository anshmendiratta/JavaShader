// Lambertian lighting model.

uniform sampler2D depthtex0, lightmap, shadowtex0, shadowtex1, shadowcolor0, colortex0, colortex1, colortex2, colortex3, colortex4, colortex5;

uniform mat4 gbufferModelView, gbufferModelViewInverse, gbufferProjectionInverse, shadowModelView, shadowProjection;
uniform vec2 mc_Entity;
uniform vec3 cameraPosition, shadowLightPosition;
uniform float viewWidth, viewHeight;
uniform int worldTime, renderStage;

in vec2 uv;
in vec2 lmcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

#include "/lib/settings.glsl"
#include "/common/utility.glsl"
#include "/common/constants.glsl"
#include "/common/noise.glsl"
#include "/common/shadow_distort.glsl"
#include "/common/shadows.glsl"

void main() {
    // Get information from gbuffers.
    vec2 lightmap_coords = texture(colortex1, uv).xy;
    vec3 normal_world_space = texture(colortex2, uv).xyz * 2.0 - 1.0;
    #if POM == 1
    vec2 parallax_coords = texture(colortex5, uv).xy;
    #endif

    color = texture(colortex0, uv);

    // Blur SSAO with a 2x2 box kernel for ambient lighting.
    float ssao_factor;
    vec2 ssao_texel_size = 1.0 / vec2(textureSize(colortex4, 0));
    const int box_kernel_n_half = 4;
    for (int x = -box_kernel_n_half; x < box_kernel_n_half; x++) {
        for (int y = -box_kernel_n_half; y < box_kernel_n_half; y++) {
            vec2 uv_offset = vec2(float(x), float(y)) * ssao_texel_size;
            ssao_factor += texture(colortex4,
                    #if POM == 1
                    parallax_coords
                    #else
                    uv
                        #endif
                        + uv_offset
                ).r;
        }
    }
    ssao_factor /= 4 * box_kernel_n_half * box_kernel_n_half;

    // Do sky pixel check.
    float depth = texture(depthtex0, uv).r;
    if (depth == 1.0) {
        return;
    }

    // Compute shadow map screen position to use to sample from the shadow map.
    vec3 fragment_ndc_space_position = vec3(uv.xy, depth) * 2.0 - 1.0;
    vec3 fragment_view_space_position = project_and_divide(gbufferProjectionInverse, fragment_ndc_space_position);
    vec3 fragment_feet_space_position = (gbufferModelViewInverse * vec4(fragment_view_space_position, 1.0)).xyz;
    vec3 shadow_view_space_position = (shadowModelView * vec4(fragment_feet_space_position, 1.0)).xyz;
    vec4 shadow_clip_space_position = shadowProjection * vec4(shadow_view_space_position, 1.0);
    vec3 shadow = get_soft_shadow(shadow_clip_space_position, normal_world_space);

    // Sun/moon light source.
    vec3 fragment_world_space_position = fragment_feet_space_position + cameraPosition;
    vec3 light_source_world_space_position = (gbufferModelViewInverse * vec4(shadowLightPosition, 1.0)).xyz + cameraPosition;
    vec3 light_source_direction_world_space = normalize(light_source_world_space_position - fragment_world_space_position);
    float n_dot_l = clamp(dot(light_source_direction_world_space, normal_world_space), 0.0, 1.0);

    float light_brightness;
    #if SPECULAR_MAPPING == 1
    vec4 specular_data = texture(colortex3, uv);
    float perceptual_roughness = specular_data.r;
    float roughness = pow(1.0 - perceptual_roughness, 2.0);
    float smoothness = 1.0 - roughness;

    // TODO: Why does the light direction need a negation?
    // vec3 R_hat = reflect(-light_source_direction_world_space, normal_world_space); // Reflected light vector.
    // vec3 V_hat = normalize(cameraPosition - fragment_world_space_position); // Point back to camera.
    // https://en.wikipedia.org/wiki/Blinn%E2%80%93Phong_reflection_model
    vec3 view_vector_world_space = fragment_world_space_position - cameraPosition;
    vec3 halfway_vector_world_space = (light_source_direction_world_space + view_vector_world_space) / length(light_source_direction_world_space + view_vector_world_space);
    float r_dot_v = clamp(dot(normal_world_space, halfway_vector_world_space), 0.0, 1.0);

    float shininess = smoothness * 200.0 + 1.0; // alpha
    float specular_light_factor = smoothness * pow(r_dot_v, 4.0 * shininess);
    float diffuse_light_factor = roughness * n_dot_l;
    light_brightness = diffuse_light_factor + specular_light_factor;
    #else
    light_brightness = n_dot_l;
    #endif
    vec3 sunlight = light_brightness * shadow * lightmap_coords.y * SUNLIGHT_COLOR * mix(SUNLIGHT_COLOR_INTENSITY, MOONLIGHT_COLOR_INTENSITY, pow(sin(worldTime / 24000.), 2.0)); // Multiply by the skylight from the light map since if an object is hidden from the sky, the object is also hidden from the sun.
    vec3 blocklight = lightmap_coords.x * BLOCKLIGHT_COLOR; // x is blocklight
    vec3 skylight = lightmap_coords.y * SKYLIGHT_COLOR; // y is skylight
    vec3 ambient = AMBIENT_COLOR * ssao_factor;
    color.rgb *= blocklight + skylight + sunlight + ambient;

    color.rgb = pow(color.rgb, vec3(2.2)); // Undo gamma correction.
}

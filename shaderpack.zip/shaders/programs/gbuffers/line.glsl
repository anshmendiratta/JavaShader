#ifdef STAGE_VERTEX
    out vec2 uv;
    out vec4 glcolor;

    #include "/include/uniforms.glsl"

    void main() {
        gl_Position = gbufferProjection * vec4((gl_ModelViewMatrix * gl_Vertex).xyz, 1.0);
        uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
        glcolor = gl_Color;
    }
#endif

#ifdef STAGE_FRAGMENT
    in vec2 uv;
    in vec4 glcolor;

    /* RENDERTARGETS: 0 */
    layout(location = 0) out vec4 color;

    #include "/include/uniforms.glsl"

    #include "/include/color/conversions.glsl"

    void main() {
        color = glcolor;

        if (renderStage == MC_RENDER_STAGE_OUTLINE) {
            color.rgb = vec3(1.0, 0.0, 0.0);
            color.a = 1.0;
        } else {
            color *= texture(gtexture, uv);
        }

        color.rgb = rgb_to_linear(color.rgb);
        if (color.a < alphaTestRef) discard;
    }
#endif

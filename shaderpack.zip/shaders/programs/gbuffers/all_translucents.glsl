#ifdef STAGE_VERTEX
#endif

#ifdef STAGE_FRAGMENT
#endif

#ifdef STAGE_VERTEX
    out vec2 uv;

    void main() {
        gl_Position = ftransform();
        uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    }
#endif

#ifdef STAGE_FRAGMENT
    in vec2 uv;

    // /* RENDERTARGETS: 0 */
    layout(location = 0) out vec4 color;

    #include "/lib/settings.glsl"

    #include "/include/uniforms.glsl"

    #include "/include/utility/math_fp.glsl"

    void main() {
        color = texture(colortex0, uv);
        float ssao_factor = pow(texture(colortex4, uv).r, AMBIENT_INTENSITY);
        ssao_factor = smoothstep01(ssao_factor);
        color.rgb *= vec3(ssao_factor);
    }
#endif

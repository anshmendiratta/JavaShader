#ifdef STAGE_VERTEX
    out vec2 uv;
    const vec2 BLOOM_INPUT_SCALE = vec2(0.25);
    const vec2 BLOOM_OUTPUT_SCALE = vec2(0.5);

    void main() {
        vec2 base_uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
        uv = base_uv * BLOOM_INPUT_SCALE;

        gl_Position = ftransform();
        gl_Position.xy = (gl_Position.xy + 1.0) * BLOOM_OUTPUT_SCALE - 1.0;
    }
#endif

#ifdef STAGE_FRAGMENT
    in vec2 uv;

    /* RENDERTARGETS: 6 */
    layout(location = 0) out vec4 bloom_upscale;

    #include "/include/settings.glsl"
    #include "/include/uniforms.glsl"
    #include "/include/post/bloom.glsl"

    void main() {
        // Fourth upscale: upsample colortex7 (1/4) -> colortex6 (1/2)
        vec2 texel_size = 1.0 / (vec2(viewWidth, viewHeight) * 0.5);
        vec3 bloom = bloom_upsample(colortex7, uv, texel_size, 2.0);
        bloom_upscale = vec4(bloom, 1.0);
    }
#endif

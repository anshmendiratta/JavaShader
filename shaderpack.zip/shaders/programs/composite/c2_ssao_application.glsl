// TODO: repurpose c2.

#ifdef STAGE_VERTEX
    in vec2 mc_midTexCoord;

    // out vec2 uv;
    // out vec2 texture_bottom_left;
    // out vec2 single_tex_size;

    void main() {
        gl_Position = ftransform();
        uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
        // vec2 half_size = abs(uv - mc_midTexCoord);
        // texture_bottom_left = mc_midTexCoord - half_size;
        // single_tex_size = half_size * 2.0;
    }
#endif

#ifdef STAGE_FRAGMENT
    in vec2 uv;
    in vec2 texture_bottom_left;
    in vec2 single_tex_size;

    // /* RENDERTARGETS: 0 */
    layout(location = 0) out vec4 color;

    #include "/lib/settings.glsl"
    #include "/lib/buffers.glsl"

    #include "/include/uniforms.glsl"

    #include "/include/utility/math_fp.glsl"

    void main() {
        color = texture(BUFFER_COLOR, uv);

        float ssao_factor = pow(texture(BUFFER_SSAO, uv).r, AMBIENT_INTENSITY);
        ssao_factor = smoothstep01(ssao_factor);

        // todo: look at later
        color.rgb *= vec3(1.0);
    }
#endif

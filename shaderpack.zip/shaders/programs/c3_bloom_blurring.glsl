// Textures.
uniform sampler2D colortex0;

uniform int viewWidth, viewHeight;

/* RENDERTARGETS: 0,6 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 blurred_light;

in vec2 uv;

#include "/lib/settings.glsl"
#include "/include/utility/random.glsl"
#include "/include/utility/noise.glsl"

// Vogel disk blur mostly taken from https://www.shadertoy.com/view/XtXXDN.
#define GOLDEN_ANGLE 2.39996322972865332 // Radians.
#define BLOOM_BLUR_SAMPLE_COUNT 16 // Hard-code value as the bloom will be fine-tuned.

// sc = sample_color
#define sc(offset_x, offset_y) texture(colortex0, uv + vec2(offset_x, offset_y) / vec2(textureSize(colortex0, 0)))

vec2 compute_vogel_disk_sample_uv(float idx) {
    float radius = sqrt((idx + 0.5) / BLOOM_BLUR_SAMPLE_COUNT);
    float theta = idx * GOLDEN_ANGLE;

    return radius * vec2(cos(theta), sin(theta));
}

void main() {
    color = texture(colortex0, uv);
    vec4 final_out = vec4(0.0);

    for (int idx = 0; idx < BLOOM_BLUR_SAMPLE_COUNT; idx += 1) {
        vec2 sample_uv = BLOOM_RADIUS * compute_vogel_disk_sample_uv(idx); // multplication by BLOOM_RADIUS is mostly arbitary and seems to produce sensible results
        final_out += sc(sample_uv.x, sample_uv.y);
    }

    final_out /= BLOOM_BLUR_SAMPLE_COUNT;

    blurred_light = final_out;
}
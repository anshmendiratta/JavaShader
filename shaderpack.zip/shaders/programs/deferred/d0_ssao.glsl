#ifdef STAGE_VERTEX
    out vec2 uv;

    void main() {
        gl_Position = ftransform();
        uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    }
#endif

#ifdef STAGE_FRAGMENT
    in vec2 uv;

    /* RENDERTARGETS: 4 */
    layout(location = 0) out float occlusion_factor;

    #include "/include/uniforms.glsl"

    #include "/include/utility/random.glsl"
    #include "/include/utility/noise.glsl"
    #include "/include/utility/depth_conversion.glsl"
    #include "/include/utility/space_conversions.glsl"
    #include "/include/utility/dither.glsl"

    #include "/include/math/convenience.glsl"

    #include "/include/pbr/material.glsl"
    #include "/include/pbr/textures.glsl"

    void main() {
        // skip ssao for hand geometry
        bool is_hand = fragment_is_hand(uv);
        if (is_hand) {
            occlusion_factor = 1.0;
            return;
        }
        // skip for the sky
        float fragment_depth = texture(depthtex2, uv).r;
        if (fragment_depth == 1.0) {
            occlusion_factor = 1.0;
            return;
        }

        vec2 screen_uv = gl_FragCoord.xy / windowDimensions;

        Material material;
        init_material_unpacked_colortex_read(material);

        vec3 fragment_position_screen = vec3(screen_uv, texture(depthtex2, screen_uv).r);
        vec3 fragment_position_view = ndc_to_view(screen_to_ndc(fragment_position_screen));
        vec3 normal_world = material.normal;
        vec3 normal_view = normalize(mat3(gbufferModelView) * normal_world);

        float dither = compute_dither(gl_FragCoord.xy);
        float epsilon_zero = compute_dither(screen_uv);
        float epsilon_one = compute_dither(screen_uv);
        float phi = 2.0 * PI * epsilon_one;
        float theta = acos(sqrt(epsilon_zero));
        vec3 random_vector = vec3(
                sin(phi) * cos(theta),
                sin(phi) * sin(theta),
                cos(theta)
            ); // to construct a tangent

        vec3 tangent_view = normalize(random_vector - normal_view * dot(normal_view, random_vector));
        vec3 bitangent_view = normalize(cross(tangent_view, normal_view));
        mat3 TBN_matrix = mat3(tangent_view, bitangent_view, normal_view); // Tangent to view.

        // Obtain depth samples for occlusion check.
        occlusion_factor = 0.0;
        for (int idx = 0; idx < SSAO_SAMPLE_COUNT; idx += 1) {
            float scale = float(idx) / float(SSAO_SAMPLE_COUNT);
            scale = smoothstep01(scale * scale); // quadratic density
            float epsilon_zero = compute_dither(screen_uv);
            float epsilon_one = compute_dither(windowDimensions - screen_uv);
            float phi = 2.0 * PI * epsilon_one;
            float theta = acos(sqrt(epsilon_zero));
            vec3 sample_offset_normal = scale * vec3(
                        cos(phi) * sin(theta),
                        sin(phi) * sin(theta),
                        abs(cos(theta))
                    );

            vec3 sample_offset_view = TBN_matrix * sample_offset_normal;
            vec3 sample_position_view = fragment_position_view + sample_offset_view;
            vec3 sample_position_screen = view_to_screen(sample_position_view);

            float sample_object_depth = texture(depthtex2, sample_position_screen.xy).r;
            vec3 sample_object_position_screen = vec3(sample_position_screen.xy, sample_object_depth);
            vec3 sample_object_position_view = screen_to_view(sample_object_position_screen);

            float is_occluded = float(sample_position_view.z <= sample_object_position_view.z + SSAO_BIAS);
            float close_in_depth = smoothstep01(SSAO_RADIUS / abs(fragment_position_view.z - sample_object_position_view.z));

            occlusion_factor += is_occluded * close_in_depth;
        }

        occlusion_factor /= float(SSAO_SAMPLE_COUNT);
        occlusion_factor = pow(1.0 - occlusion_factor, AMBIENT_INTENSITY);
    }
#endif

// Textures.
uniform sampler2D colortex0, colortex6; // Bloom.

in vec2 uv;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

#include "/include/color/conversions.glsl"

// TODO: Bloom colortex is completely black.
void main() {
    color = texture(colortex0, uv);
    vec4 blurred = texture(colortex6, uv);
    if (rgb_to_luminance(blurred.rgb) >= 1.0) {
        color += blurred;
    }
}

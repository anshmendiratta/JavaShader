// Textures.
uniform sampler2D colortex0;

uniform int viewWidth, viewHeight;

/* RENDERTARGETS: 0,7 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 blurred_light;

in vec2 uv;

#include "/common/utility.glsl"
#include "/common/noise.glsl"
#include "/common/math.glsl"

// sc = sample_color
#define sc(offset_x, offset_y) texture(colortex0, uv + vec2(offset_x, offset_y) / vec2(textureSize(colortex0, 0)))

// 5x5 Gaussian blur kernel.
// const mat5 kernel = mat5(
//         1.0 / 256.0, 4.0 / 256.0, 6.0 / 256.0, 4.0 / 256.0, 1.0 / 256.0,
//         4.0 / 256.0, 16.0 / 256.0, 24.0 / 256.0, 16.0 / 256.0, 4.0 / 256.0,
//         6.0 / 256.0, 24.0 / 256.0, 36.0 / 256.0, 24.0 / 256.0, 6.0 / 256.0,
//         4.0 / 256.0, 16.0 / 256.0, 24.0 / 256.0, 16.0 / 256.0, 4.0 / 256.0,
//         1.0 / 256.0, 4.0 / 256.0, 6.0 / 256.0, 4.0 / 256.0, 1.0 / 256.0
//     );

// TODO: Bloom colortex is completely black.
void main() {
    color = texture(colortex0, uv);

    vec4 final_out = vec4(0.0);

    final_out.r =
        (1.0 / 256.0) * (sc(-2, 2).r + sc(2, 2).r + sc(-2, -2).r + sc(2, -2).r) +
            (4.0 / 256.0) * (sc(-1, 2).r + sc(1, 2).r + sc(-2, 1).r + sc(2, 1).r + sc(-2, -1).r + sc(2, -1).r + sc(-1, -2).r + sc(1, -2).r) +
            (6.0 / 256.0) * (sc(0, 2).r + sc(-2, 0).r + sc(2, 0).r + sc(0, -2).r) +
            (16.0 / 256.0) * (sc(-1, 1).r + sc(1, 1).r + sc(-1, -1).r + sc(1, -1).r) +
            (24.0 / 256.0) * (sc(-1, 0).r + sc(1, 0).r + sc(0, 1).r + sc(0, -1).r) +
            (36.0 / 256.0) * sc(0, 0).r;

    final_out.g =
        (1.0 / 256.0) * (sc(-4, 4).g + sc(4, 4).g + sc(-4, -4).g + sc(4, -4).g) +
            (4.0 / 256.0) * (sc(-1, 2).g + sc(1, 2).g + sc(-2, 1).g + sc(2, 1).g + sc(-2, -1).g + sc(2, -1).g + sc(-1, -2).g + sc(1, -2).g) +
            (6.0 / 256.0) * (sc(0, 2).g + sc(-2, 0).g + sc(2, 0).g + sc(0, -2).g) +
            (16.0 / 256.0) * (sc(-1, 1).g + sc(1, 1).g + sc(-1, -1).g + sc(1, -1).g) +
            (24.0 / 256.0) * (sc(-1, 0).g + sc(1, 0).g + sc(0, 1).g + sc(0, -1).g) +
            (36.0 / 256.0) * sc(0, 0).g;

    final_out.b =
        (1.0 / 256.0) * (sc(-4, 4).b + sc(4, 4).b + sc(-4, -4).b + sc(4, -4).b) +
            (4.0 / 256.0) * (sc(-1, 2).b + sc(1, 2).b + sc(-2, 1).b + sc(2, 1).b + sc(-2, -1).b + sc(2, -1).b + sc(-1, -2).b + sc(1, -2).b) +
            (6.0 / 256.0) * (sc(0, 2).b + sc(-2, 0).b + sc(2, 0).b + sc(0, -2).b) +
            (16.0 / 256.0) * (sc(-1, 1).b + sc(1, 1).b + sc(-1, -1).b + sc(1, -1).b) +
            (24.0 / 256.0) * (sc(-1, 0).b + sc(1, 0).b + sc(0, 1).b + sc(0, -1).b) +
            (36.0 / 256.0) * sc(0, 0).b;

    final_out.a =
        (1.0 / 256.0) * (sc(-4, 4).a + sc(4, 4).a + sc(-4, -4).a + sc(4, -4).a) +
            (4.0 / 256.0) * (sc(-1, 2).a + sc(1, 2).a + sc(-2, 1).a + sc(2, 1).a + sc(-2, -1).a + sc(2, -1).a + sc(-1, -2).a + sc(1, -2).a) +
            (6.0 / 256.0) * (sc(0, 2).a + sc(-2, 0).a + sc(2, 0).a + sc(0, -2).a) +
            (16.0 / 256.0) * (sc(-1, 1).a + sc(1, 1).a + sc(-1, -1).a + sc(1, -1).a) +
            (24.0 / 256.0) * (sc(-1, 0).a + sc(1, 0).a + sc(0, 1).a + sc(0, -1).a) +
            (36.0 / 256.0) * sc(0, 0).a;

    blurred_light = final_out;
}

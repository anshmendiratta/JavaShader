#if !defined INCLUDE_BLOOM
    #define INCLUDE_BLOOM

    #include "/include/utility/dither.glsl"

    vec3 bloom_downsample(sampler2D bloom_texture, ) {}

    vec3 bloom_upsample() {}

    // line two basically taken from shrimple: https://github.com/Null-MC/Shrimple/blob/f4fcab627cc62bd2e66813c58cd657bb4ecbb84f/shaders/lib/effects/bloom.glsl#L132
    void dither_bloom(inout vec3 color) {
        float dither = compute_dither(gl_FragCoord.xy);
        color += (dither - 0.25) / 32.0e3;
    }
#endif

#include "/lib/settings.glsl"

// Sky/fog.
const vec3 SKY_COLOR_HORIZON = vec3(0.3, 0.58, 1.0);
const vec3 FOG_COLOR = SKY_COLOR_HORIZON;
// Lighting.
const vec3 BLOCKLIGHT_COLOR = vec3(BLOCKLIGHT_R, BLOCKLIGHT_G, BLOCKLIGHT_B);
const vec3 SUNLIGHT_COLOR = vec3(SUNLIGHT_INTENSITY);
const vec3 SKYLIGHT_COLOR = vec3(0.4);

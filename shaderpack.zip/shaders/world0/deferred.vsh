#version 430 compatibility

#define STAGE_VERTEX
#include "/programs/deferred/d0_ssao.glsl"

#version 430

#define STAGE_VERTEX
#include "/programs/gbuffers/line.glsl"

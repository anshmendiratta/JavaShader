#version 430

#define STAGE_FRAGMENT
#include "/programs/gbuffers/line.glsl"

// Shadows.
// const int noiseTextureResolution = NOISE_TEXTURE_RESOLUTION;
const int shadowMapResolution = SHADOW_MAP_RESOLUTION; // Shadow map resolution in pixels. [512 1024 2048 4096]
// const bool shadowtex0Nearest = true;
// const bool shadowtex1Nearest = true;
// const bool shadowcolor0Nearest = true;

const float ambientOcclusionLevel = 0.0;

const float sunPathRotation = 20.0;
